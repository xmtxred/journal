using Microsoft.EntityFrameworkCore;
using BookTrade.Models;

namespace BookTrade.Data
{
    public class BookTradeContext : DbContext
    {
        public BookTradeContext(DbContextOptions<BookTradeContext> options) : base(options) { }
        public DbSet<Book> Books => Set<Book>();
    }
}
