using Microsoft.AspNetCore.Mvc;
using BookTrade.Models;
using System.Diagnostics;

namespace BookTrade.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var books = new List<Book>
            {
                new Book { Id = 1, Title = "Мастер и Маргарита", Author = "Михаил Булгаков", Price = 9.99m, Condition = "Хорошее" },
                new Book { Id = 2, Title = "Три товарища", Author = "Эрих Мария Ремарк", Price = 7.50m, Condition = "Отличное" },
                new Book { Id = 3, Title = "Над пропастью во ржи", Author = "Дж. Д. Сэлинджер", Price = 6.25m, Condition = "Удовлетворительное" }
            };
            return View(books);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
