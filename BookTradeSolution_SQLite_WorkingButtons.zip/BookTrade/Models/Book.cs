using System.ComponentModel.DataAnnotations;

namespace BookTrade.Models
{
    public class Book
    {
        public int Id { get; set; }

        [Required, StringLength(200)]
        [Display(Name = "Название")]
        public string Title { get; set; } = string.Empty;

        [Required, StringLength(200)]
        [Display(Name = "Автор")]
        public string Author { get; set; } = string.Empty;

        [Range(0, 100000)]
        [Display(Name = "Цена")]
        public decimal Price { get; set; }

        [StringLength(100)]
        [Display(Name = "Состояние")]
        public string Condition { get; set; } = "Хорошее";
    }
}
